const mysql = require('mysql');

const conexion = mysql.createConnection({
  host: 'localhost',
  user: 'root',
  password: 'root',
  database: 'quimicos'
});

conexion.connect((error) => {
  if (error) {
    console.error('Error al conectar a la base de datos: ' + error.message);
    return;
  }
  console.log('Conexión exitosa a la base de datos MySQL');
});

//QUERY TABLA CLIENTES
conexion.query('SELECT * FROM clientes', (error, resultados, campos) => {
    if (error) {
      console.error('Error al realizar la consulta: ' + error.message);
      return;
    }
    console.log('Resultados de la consulta:', resultados);
  });
  
//QUERY TABLA PRODUCTOS
conexion.query('SELECT * FROM productos', (error, resultados, campos) => {
    if (error) {
      console.error('Error al realizar la consulta: ' + error.message);
      return;
    }
    console.log('Resultados de la consulta:', resultados);
  });  
  
//QUERY TABLA FACTURAS
conexion.query('SELECT * FROM facturas', (error, resultados, campos) => {
    if (error) {
      console.error('Error al realizar la consulta: ' + error.message);
      return;
    }
    console.log('Resultados de la consulta:', resultados);
  });  


  conexion.end();