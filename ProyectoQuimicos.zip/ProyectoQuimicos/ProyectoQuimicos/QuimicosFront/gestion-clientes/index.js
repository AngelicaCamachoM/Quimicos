const express = require('express');
const bodyParser = require('body-parser');
const cors = require('cors');
const path = require('path');

const app = express();
const clientsRouter = require('../routes/clients');

app.use(cors());
app.use(bodyParser.json());
app.use(express.static(path.join(__dirname, 'public')));

app.use('/api', clientsRouter);

app.listen(3000, () => {
  console.log('Servidor corriendo en el puerto 3000');
});
