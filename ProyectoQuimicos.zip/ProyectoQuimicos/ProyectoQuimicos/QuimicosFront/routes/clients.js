const express = require('express');
const router = express.Router();
const db = require('../db');

// Ruta para obtener todos los clientes
router.get('/clientes', (req, res) => {
  const query = 'SELECT c.*, l.nombre_lugar FROM clientes c JOIN lugares l ON c.cod_lugares = l.cod_lugares';
  db.query(query, (err, results) => {
    if (err) throw err;
    res.json(results);
  });
});

module.exports = router;
