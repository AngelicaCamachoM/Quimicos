document.addEventListener('DOMContentLoaded', () => {
    fetchClientes();
    cargarLugares();
});

function fetchClientes() {
    fetch('http://localhost:3000/api/clientes')
        .then(response => response.json())
        .then(data => {
            const clientesList = document.getElementById('clientesList');
            clientesList.innerHTML = '';
            data.forEach(cliente => {
                const row = document.createElement('tr');
                row.innerHTML = `
                    <td>${cliente.nombre}</td>
                    <td>${cliente.cedula}</td>
                    <td>${cliente.telefono}</td>
                    <td>${cliente.direccion}</td>
                    <td>${cliente.nombre_lugar}</td>
                    <td class="button-container">
                        <button onclick="eliminarCliente(${cliente.id_cliente})">Eliminar</button>
                        <button onclick="actualizarCliente(${cliente.id_cliente})">Editar</button>
                    </td>
                `;
                clientesList.appendChild(row);
            });
        });
}

function cargarLugares() {
    fetch('http://localhost:3000/api/lugares')
        .then(response => response.json())
        .then(data => {
            const lugaresSelect = document.getElementById('cod_lugares');
            data.forEach(lugar => {
                const option = document.createElement('option');
                option.value = lugar.cod_lugares;
                option.textContent = lugar.nombre_lugar;
                lugaresSelect.appendChild(option);
            });
        });
}
