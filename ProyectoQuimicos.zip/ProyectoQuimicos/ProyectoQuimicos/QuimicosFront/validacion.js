var objPeople = [
    {
        c_usuario: "admininicial",
        c_contraseña : "admin123456",
    }

]

function validate(){
    var c_usuario = document.getElementById('c_usuario').value
    var c_contraseña = document.getElementById('c_contraseña').value

    if(c_usuario == "admininicial" && c_contraseña == "admin123456"){
        alert("Ingreso exitoso");
        window.location = "index.html";
        return false;
    }
    else{
        alert("Usuario incorrecto");
    }
    app.listen(3000,() => {
        console.log('Servidor inicia puerto 3000')
    })
}
